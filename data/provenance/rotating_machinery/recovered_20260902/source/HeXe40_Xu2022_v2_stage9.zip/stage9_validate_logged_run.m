function R = stage9_validate_logged_run(testName, D)
%STAGE9_VALIDATE_LOGGED_RUN Validate logged outputs against Xu Ch.5 behavior.
%
% D must be a table with columns as needed:
%   time_s, N_rpm, Ptac_kW, mdot_kg_s
%
% Supported testName:
%   'stageIII', 'stable_plus5', 'stable_minus5', 'load_disturbance'
%
% Engineering tolerances below are defaults, NOT thesis-prescribed tolerances.
tolN = 0.01;      % 1%
tolP = 0.02;      % 2%
tolApprox = 0.05; % 5% for quantities described as "about"

Nd=55090.000000000000;
R=struct('test',testName,'PASS',false,'checks',struct());

switch lower(testName)
case 'stageiii'
    R.checks.speed = abs(D.N_rpm(end)-22036.000000000000) <= tolApprox*22036.000000000000;
    R.checks.power = abs(D.Ptac_kW(end)-115) <= tolApprox*115;
    R.checks.flow  = abs(D.mdot_kg_s(end)-10.02) <= tolApprox*10.02;
    R.PASS = R.checks.speed && R.checks.power && R.checks.flow;

case 'stable_plus5'
    pre = median(D.Ptac_kW(D.time_s>=450 & D.time_s<500));
    post = median(D.Ptac_kW(D.time_s>=500 & D.time_s<520));
    R.checks.initial_power_decreases = post < pre;
    R.checks.final_speed_recovers = abs(D.N_rpm(end)-Nd) <= tolN*Nd;
    R.checks.final_power_recovers = abs(D.Ptac_kW(end)-1000) <= tolP*1000;
    R.PASS = R.checks.initial_power_decreases && R.checks.final_speed_recovers && R.checks.final_power_recovers;

case 'stable_minus5'
    pre = median(D.Ptac_kW(D.time_s>=450 & D.time_s<500));
    post = median(D.Ptac_kW(D.time_s>=500 & D.time_s<520));
    R.checks.initial_power_increases = post > pre;
    R.checks.final_speed_recovers = abs(D.N_rpm(end)-Nd) <= tolN*Nd;
    R.checks.final_power_recovers = abs(D.Ptac_kW(end)-1000) <= tolP*1000;
    R.PASS = R.checks.initial_power_increases && R.checks.final_speed_recovers && R.checks.final_power_recovers;

case 'load_disturbance'
    n1=median(D.N_rpm(D.time_s>=1400 & D.time_s<1500));
    n2=median(D.N_rpm(D.time_s>=2400 & D.time_s<2500));
    n3=median(D.N_rpm(D.time_s>=max(D.time_s(end)-200,2500)));
    R.checks.speed_950kW = abs(n1-59655) <= tolN*59655;
    R.checks.speed_1000kW = abs(n2-55090) <= tolN*55090;
    R.checks.speed_1050kW = abs(n3-50610) <= tolN*50610;
    R.PASS = R.checks.speed_950kW && R.checks.speed_1000kW && R.checks.speed_1050kW;

otherwise
    error('Unknown testName.');
end
disp(R)
end
