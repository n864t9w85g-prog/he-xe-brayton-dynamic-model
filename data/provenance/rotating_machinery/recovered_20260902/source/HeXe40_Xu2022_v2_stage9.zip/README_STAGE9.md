# Xu-2022 He-Xe lookup reconstruction — Stage 9

## Critical new finding

Stage 8 capped the candidate map at 100% speed = 55090 rpm.
That is insufficient for two thesis validation cases:

- stable-point +5% speed perturbation: 57844.5 rpm = 105%
- 950 kW load case final stable speed: 59655 rpm = 108.29%

Therefore Stage 8 cannot reproduce the full Chapter-5 dynamic validation envelope
without extrapolating the lookup tables.

## Stage-9 policy

The 40%-100% central map is preserved unchanged.
A separate 100%-110% extension is generated ONLY for model-validation tests.

Extension method:
- at each line coordinate q, extrapolate the 90%-100% trend linearly in speed;
- preserve PR above unity;
- keep efficiency finite and bounded;
- mark every >100% mother-data row as `EXTRAPOLATED_100_TO_110_TEST_ONLY`.

This is not Xu original data and should not silently replace the Stage-8 central map in
production studies.

## Thesis validation cases encoded

1. Stage III startup:
   0 -> 40% speed in about 100 s;
   final TAC power ~115 kWe;
   He-Xe flow ~10.02 kg/s.

2. Stage IV:
   linearly increase speed to 55090 rpm in about 2000 s;
   then maintain steady conditions for about 2000 s.

3. Stable-point +5% speed perturbation at t=500 s:
   TAC power initially decreases, and speed/power ultimately return to the original stable point.

4. Stable-point -5% perturbation:
   TAC power initially increases, and speed/power ultimately return.

5. TAC-load sequence:
   1000 kW -> 950 kW at 500 s -> 1000 kW at 1500 s -> 1050 kW at 2500 s.
   Thesis final stable speeds:
   59655 -> 55090 -> 50610 rpm.

## Important execution status

I could not execute the actual Simulink model in this environment because no `.slx`
or `.mdl` model file is available in the conversation/library, and the connected GitHub
installation did not resolve the referenced repository.

`stage9_scan_model_for_lookup.m` is read-only and inventories the real lookup blocks
without saving the model.  Once the model is locally available, run that first.

`stage9_validate_logged_run.m` checks logged model outputs against the thesis behavior.
It does not alter the Simulink model.

## Status

Stage-9 100%-110% values are TEST-ONLY EXTRAPOLATION.
Stage-8 remains the preferred central candidate over 40%-100% speed.
