function T = stage9_scan_model_for_lookup(modelName)
%STAGE9_SCAN_MODEL_FOR_LOOKUP Read-only inventory of n-D Lookup Table blocks.
% Does not save or modify the Simulink model.
%
% Example:
%   T = stage9_scan_model_for_lookup('final_dynamic_24a');
%
if nargin<1 || strlength(string(modelName))==0
    error('Provide model name/path, e.g. final_dynamic_24a');
end
[~,mdl,~]=fileparts(char(modelName));
load_system(char(modelName));
c = onCleanup(@() close_system(mdl,0));

blocks = find_system(mdl,'FollowLinks','on','LookUnderMasks','all','BlockType','Lookup_n-D');
rows = cell(numel(blocks),7);
for i=1:numel(blocks)
    b=blocks{i};
    rows{i,1}=b;
    rows{i,2}=get_param(b,'Name');
    rows{i,3}=safeget(b,'Table');
    rows{i,4}=safeget(b,'BreakpointsForDimension1');
    rows{i,5}=safeget(b,'BreakpointsForDimension2');
    rows{i,6}=safeget(b,'InterpMethod');
    rows{i,7}=safeget(b,'ExtrapMethod');
end
T=cell2table(rows,'VariableNames',{'BlockPath','Name','Table','BP1','BP2','Interp','Extrap'});
writetable(T,'stage9_lookup_inventory.csv');
disp(T);

end
function v=safeget(b,p)
try, v=get_param(b,p); catch, v=''; end
end
